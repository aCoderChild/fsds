#!/usr/bin/env python3
"""Generate and score held-out multilingual direct/MH probes for R1.

Gold labels are loaded only by the scoring process, after generation. The model
receives question-only prompts. Translation readiness is checked fail-closed.
"""
import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from pathlib import Path

LANGS = ("en", "fr", "de", "hi", "th")


def read_jsonl(p):
    with Path(p).open(encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def normalize(s):
    s = unicodedata.normalize("NFKC", str(s)).casefold()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    return " ".join(s.split())


def exact_answer(pred, gold):
    return normalize(pred) == normalize(gold)


def load_eval(eval_root):
    root = Path(eval_root)
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("evaluation_ready") is not True or manifest.get("ai_review_status") != "AI_ONLY_REVIEWED_COMPLETE":
        raise RuntimeError("Non-English evaluation translations have not passed complete AI-only review")
    prompts = {"en": read_jsonl(root / "prompts/en.jsonl")}
    for lang in LANGS[1:]:
        p = root / "translations/ai_reviewed" / f"{lang}.jsonl"
        rows = read_jsonl(p)
        if len(rows) != 258 or any(r.get("review_status") != "AI_REVIEWED" for r in rows):
            raise RuntimeError(f"AI-reviewed {lang} prompts are incomplete or mislabeled")
        prompts[lang] = rows
    prompt_by_case = {}
    for lang in LANGS:
        for row in prompts[lang]:
            iid = row["instance_id"] if lang == "en" else row["translation_id"].split(":", 1)[0]
            probe = row["probe"] if lang == "en" else row["translation_id"].split(":")[1]
            prompt_by_case[(iid, probe, lang)] = row
    expected_iids = {row["instance_id"] for row in prompts["en"]}
    expected = {(iid, probe, lang) for iid in expected_iids for probe in ("direct", "multi") for lang in LANGS}
    if set(prompt_by_case) != expected:
        raise RuntimeError(f"Prompt coverage mismatch: missing={len(expected-set(prompt_by_case))}, extra={len(set(prompt_by_case)-expected)}")
    return manifest, prompt_by_case


def load_labels(eval_root):
    labels = read_jsonl(Path(eval_root) / "labels/gold_labels.jsonl")
    label_by_id = {r["instance_id"]: r for r in labels}
    if len(labels) != 129 or len(label_by_id) != 129:
        raise RuntimeError("Expected 129 separate gold label rows")
    if any(not row.get("bootstrap_cluster_id") for row in labels):
        raise RuntimeError("Gold labels must include the leakage-isolated entity group for clustered inference")
    return label_by_id


def score(predictions_path, labels, output_dir, bootstrap=2000):
    import random
    rows = read_jsonl(predictions_path)
    label_by_id = labels
    seen = set()
    scored = []
    for p in rows:
        key = (p["model"], p["instance_id"], p["probe"], p["language"])
        if key in seen:
            raise RuntimeError(f"Duplicate prediction: {key}")
        seen.add(key)
        if p["instance_id"] not in label_by_id:
            raise RuntimeError(f"Prediction has unknown evaluation instance: {p['instance_id']}")
        if p["probe"] not in {"direct", "multi"} or p["language"] not in LANGS:
            raise RuntimeError(f"Prediction has invalid probe/language: {key}")
        if p.get("split") != label_by_id[p["instance_id"]].get("split"):
            raise RuntimeError(f"Prediction split disagrees with gold-label split: {key}")
        gold_row = label_by_id[p["instance_id"]]
        answers = gold_row["direct_intermediate_answer"] if p["probe"] == "direct" else gold_row["final_answers"]
        if isinstance(answers, str): answers = [answers]
        correct = any(exact_answer(p.get("answer", ""), g) for g in answers)
        scored.append({**p, "correct": correct, "gold_answers": answers})
    models = {r["model"] for r in scored}
    if "sft" not in models:
        raise RuntimeError("Complete scoring requires the SFT baseline checkpoint")
    expected_per_model = {
        (iid, probe, lang)
        for iid in label_by_id
        for probe in ("direct", "multi")
        for lang in LANGS
    }
    for model in models:
        actual = {(r["instance_id"], r["probe"], r["language"]) for r in scored if r["model"] == model}
        if actual != expected_per_model:
            raise RuntimeError(f"Incomplete evaluation predictions for {model}: missing={len(expected_per_model-actual)}, extra={len(actual-expected_per_model)}")
    groups = defaultdict(dict)
    for r in scored:
        groups[(r["model"], r["instance_id"], r["language"])][r["probe"]] = r
    summaries = []
    case_rows = []
    def boot_ci(cluster_values, seed):
        clusters = sorted(cluster_values)
        if not clusters: return (None, None)
        point_values = [value for cluster in clusters for value in cluster_values[cluster]]
        if len(clusters) == 1:
            point = sum(point_values) / len(point_values)
            return (point, point)
        rng = random.Random(seed)
        estimates=[]
        for _ in range(bootstrap):
            sampled_clusters=[clusters[rng.randrange(len(clusters))] for _ in clusters]
            sample=[value for cluster in sampled_clusters for value in cluster_values[cluster]]
            estimates.append(sum(sample)/len(sample))
        estimates.sort()
        return estimates[int(0.025*(len(estimates)-1))], estimates[int(0.975*(len(estimates)-1))]
    for (model, iid, lang), probes in groups.items():
        if not {"direct", "multi"} <= probes.keys():
            raise RuntimeError(f"Missing paired direct/multi output: {model}/{iid}/{lang}")
        direct, multi = probes["direct"], probes["multi"]
        case_rows.append({"model": model, "instance_id": iid, "split": direct["split"],
                          "bootstrap_cluster_id": label_by_id[iid]["bootstrap_cluster_id"], "language": lang,
                          "direct_correct": direct["correct"], "multi_correct": multi["correct"],
                          "direct_generation_failed": direct.get("generation_failed", False),
                          "multi_generation_failed": multi.get("generation_failed", False)})
    baseline_name = "sft"
    base_lookup = {(r["instance_id"], r["language"]): r for r in case_rows if r["model"] == baseline_name}
    for model in sorted({r["model"] for r in case_rows}):
        for lang in LANGS:
            for split in ("forget", "retain", "holdout"):
                sub = [r for r in case_rows if r["model"] == model and r["language"] == lang and r["split"] == split]
                if not sub: continue
                eligible = [r for r in sub if (base_lookup.get((r["instance_id"],lang), {}).get("direct_correct") and base_lookup.get((r["instance_id"],lang), {}).get("multi_correct"))]
                direct_acc = sum(r["direct_correct"] for r in sub) / len(sub)
                mh_acc = sum(r["multi_correct"] for r in sub) / len(sub)
                retain_base = [r for r in case_rows if r["model"] == baseline_name and r["language"] == lang and r["split"] == split]
                base_mh = sum(r["multi_correct"] for r in retain_base) / len(retain_base) if retain_base else None
                d_direct = (sum(r["direct_correct"] for r in retain_base) / len(retain_base) - direct_acc) if retain_base else None
                delta_mh = mh_acc - base_mh if base_mh is not None else None
                daf = [r for r in eligible if not r["direct_correct"]]
                dap = sum(r["multi_correct"] for r in daf) / len(daf) if daf else None
                eligible_deltas=defaultdict(list)
                for r in eligible:
                    before=base_lookup[(r["instance_id"],lang)]["multi_correct"]
                    eligible_deltas[r["bootstrap_cluster_id"]].append(int(r["multi_correct"])-int(before))
                eligible_delta_values=[v for group in eligible_deltas.values() for v in group]
                precomp_delta=sum(eligible_delta_values)/len(eligible_delta_values) if eligible_delta_values else None
                seed=int(hashlib.sha256(f"{model}|{lang}|{split}".encode()).hexdigest()[:8],16)
                precomp_lo,precomp_hi=boot_ci(eligible_deltas,seed)
                summaries.append({"model": model, "language": lang, "split": split, "n": len(sub),
                                  "precompetent_n": len(eligible), "precompetent_entity_groups": len(eligible_deltas),
                                  "direct_accuracy": direct_acc, "multi_accuracy": mh_acc,
                                  "delta_multi_vs_sft_pp": 100*delta_mh if delta_mh is not None else None,
                                  "eligible_multi_accuracy": sum(r["multi_correct"] for r in eligible)/len(eligible) if eligible else None,
                                  "eligible_multi_delta_vs_sft_pp": 100*precomp_delta if precomp_delta is not None else None,
                                  "eligible_multi_delta_95ci_pp": [100*precomp_lo,100*precomp_hi] if precomp_lo is not None else None,
                                  "direct_forgetting_vs_sft_pp": 100*d_direct if model != baseline_name and d_direct is not None else 0,
                                  "dap": dap, "dap_denominator": len(daf),
                                  "invalid_generation_rate": sum(r["direct_generation_failed"]+r["multi_generation_failed"] for r in sub)/(2*len(sub))})
    # Primary hypothesis contrast: within each leakage-isolated chain group,
    # compare the post-vs-SFT change in a non-English language with the same
    # change in English. Negative values indicate greater non-English loss.
    contrasts = []
    by_model_case_lang = {(r["model"], r["instance_id"], r["language"]): r for r in case_rows}
    for model in sorted(models - {baseline_name}):
        for split in ("forget", "retain", "holdout"):
            for lang in LANGS[1:]:
                paired = []
                for iid, label in label_by_id.items():
                    if label["split"] != split:
                        continue
                    sft_en = by_model_case_lang.get((baseline_name, iid, "en"))
                    sft_l = by_model_case_lang.get((baseline_name, iid, lang))
                    model_en = by_model_case_lang.get((model, iid, "en"))
                    model_l = by_model_case_lang.get((model, iid, lang))
                    if not all((sft_en, sft_l, model_en, model_l)):
                        continue
                    # Restrict to cases learned on both language probes before
                    # unlearning; this avoids counting prior language failure.
                    if not all((sft_en["direct_correct"], sft_en["multi_correct"],
                                sft_l["direct_correct"], sft_l["multi_correct"])):
                        continue
                    en_effect = int(model_en["multi_correct"]) - int(sft_en["multi_correct"])
                    lang_effect = int(model_l["multi_correct"]) - int(sft_l["multi_correct"])
                    paired.append({"instance_id": iid, "cluster": label["bootstrap_cluster_id"],
                                   "en_effect": en_effect, "language_effect": lang_effect,
                                   "did": lang_effect - en_effect})
                clusters = sorted({r["cluster"] for r in paired})
                point_en = sum(r["en_effect"] for r in paired) / len(paired) if paired else None
                point_lang = sum(r["language_effect"] for r in paired) / len(paired) if paired else None
                point_did = sum(r["did"] for r in paired) / len(paired) if paired else None
                lo = hi = None
                if len(clusters) >= 2:
                    seed = int(hashlib.sha256(f"{model}|{lang}|{split}|cluster-did".encode()).hexdigest()[:8], 16)
                    rng = random.Random(seed)
                    members = {cluster: [r for r in paired if r["cluster"] == cluster] for cluster in clusters}
                    estimates = []
                    for _ in range(bootstrap):
                        sampled_clusters = [clusters[rng.randrange(len(clusters))] for _ in clusters]
                        sampled = [r for cluster in sampled_clusters for r in members[cluster]]
                        estimates.append(sum(r["did"] for r in sampled) / len(sampled))
                    estimates.sort()
                    lo = estimates[int(0.025 * (len(estimates) - 1))]
                    hi = estimates[int(0.975 * (len(estimates) - 1))]
                elif paired:
                    lo = hi = point_did
                contrasts.append({"model": model, "split": split, "language": lang,
                                  "n_bilingual_precompetent_cases": len(paired), "n_entity_groups": len(clusters),
                                  "english_multi_delta_vs_sft_pp": 100 * point_en if point_en is not None else None,
                                  "language_multi_delta_vs_sft_pp": 100 * point_lang if point_lang is not None else None,
                                  "language_minus_english_did_pp": 100 * point_did if point_did is not None else None,
                                  "cluster_bootstrap_95ci_pp": [100 * lo, 100 * hi] if lo is not None else None})
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    (out / "scored_predictions.jsonl").write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in scored),encoding="utf-8")
    (out / "case_metrics.jsonl").write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in case_rows),encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summaries,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    if summaries:
        with (out/"summary.csv").open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
    with (out/"cross_language_contrasts.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(contrasts[0]) if contrasts else ["model","split","language"]);w.writeheader();w.writerows(contrasts)
    (out/"cross_language_contrasts.json").write_text(json.dumps(contrasts,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    report=["# R1 cross-lingual unlearning diagnostics", "", "AI-only-reviewed translations; not human-validated. Strict normalized exact gold-answer matching; generation failures count as incorrect. Eligible MH delta is paired within cases both answered correctly by SFT. Confidence intervals resample leakage-isolated entity groups. Main English-vs-language contrasts use only bilingual precompetent cases. The pilot is exploratory; intervals are not multiplicity-adjusted.", "",
            "| Model | Language | Split | N | Precompetent | Direct acc. | MH acc. | Full MH Δ (pp) | Eligible MH Δ (95% CI, pp) | DAP | Invalid gen. |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in summaries:
        fmt=lambda x: "N/A" if x is None else f"{100*x:.1f}%"
        mh_delta = "N/A" if r["delta_multi_vs_sft_pp"] is None else f"{r['delta_multi_vs_sft_pp']:+.1f}"
        ci = r["eligible_multi_delta_95ci_pp"]
        e_delta = "N/A" if r["eligible_multi_delta_vs_sft_pp"] is None else f"{r['eligible_multi_delta_vs_sft_pp']:+.1f} ({ci[0]:+.1f},{ci[1]:+.1f})"
        report.append(f"| {r['model']} | {r['language']} | {r['split']} | {r['n']} | {r['precompetent_n']} | {fmt(r['direct_accuracy'])} | {fmt(r['multi_accuracy'])} | {mh_delta} | {e_delta} | {fmt(r['dap'])} | {fmt(r['invalid_generation_rate'])} |")
    report += ["", "## Primary contrast: language effect minus English effect", "",
               "Negative values mean the post-unlearning multi-hop change is more negative in the listed language than in English. Cohort is restricted to cases where SFT answered both direct and multi-hop probes correctly in both languages. Confidence intervals resample entity groups, preserving within-group dependence. Pilot intervals are exploratory.", "",
               "| Model | Split | Language | Bilingual cases | Entity groups | EN Δ (pp) | Language Δ (pp) | Language − EN (95% CI, pp) |", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for r in contrasts:
        ci=r["cluster_bootstrap_95ci_pp"]
        did="N/A" if r["language_minus_english_did_pp"] is None else f"{r['language_minus_english_did_pp']:+.1f} ({ci[0]:+.1f},{ci[1]:+.1f})"
        en="N/A" if r["english_multi_delta_vs_sft_pp"] is None else f"{r['english_multi_delta_vs_sft_pp']:+.1f}"
        other="N/A" if r["language_multi_delta_vs_sft_pp"] is None else f"{r['language_multi_delta_vs_sft_pp']:+.1f}"
        report.append(f"| {r['model']} | {r['split']} | {r['language']} | {r['n_bilingual_precompetent_cases']} | {r['n_entity_groups']} | {en} | {other} | {did} |")
    (out/"diagnostic_report.md").write_text("\n".join(report)+"\n",encoding="utf-8")


def generate(manifest, prompts, checkpoints, outpath, max_new_tokens):
    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer
    rows=[]
    english_prompts=read_jsonl(Path(__file__).resolve().parents[1]/"evaluation_dataset/prompts/en.jsonl")
    split_by_id={r["instance_id"]:r["split"] for r in english_prompts}
    for checkpoint in checkpoints:
        name, path = checkpoint.split("=",1)
        path=Path(path)
        is_adapter=path.is_dir() and (path/"adapter_config.json").is_file()
        model_id=manifest.get("model_id","meta-llama/Llama-3.2-1B-Instruct")
        tok=AutoTokenizer.from_pretrained(path if is_adapter else model_id,token=True)
        dtype=torch.float16 if torch.cuda.is_available() else torch.float32
        model=AutoModelForCausalLM.from_pretrained(model_id,token=True,torch_dtype=dtype,device_map="auto")
        if is_adapter: model=PeftModel.from_pretrained(model,path)
        model.eval()
        for lang in LANGS:
            for (iid, probe, plang), p in prompts.items():
                if plang!=lang: continue
                failure_type=None
                messages=[{"role":"user","content":p["question"]+"\nAnswer with the shortest answer possible."}]
                ids=tok.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_tensors="pt").to(model.device)
                try:
                    with torch.inference_mode():
                        output=model.generate(ids,do_sample=False,max_new_tokens=max_new_tokens,pad_token_id=tok.eos_token_id,eos_token_id=tok.eos_token_id)
                    answer=tok.decode(output[0,ids.shape[-1]:],skip_special_tokens=True).strip()
                    failed=not bool(answer)
                except Exception as exc:
                    answer="";failed=True;failure_type=type(exc).__name__
                row={"model":name,"instance_id":iid,"probe":probe,"split":(p["split"] if lang=="en" else split_by_id[iid]),"language":lang,"answer":answer,"generation_failed":failed}
                if failed and failure_type: row["failure_type"]=failure_type
                rows.append(row)
        del model
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    Path(outpath).parent.mkdir(parents=True,exist_ok=True)
    Path(outpath).write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in rows),encoding="utf-8")


def main():
    p=argparse.ArgumentParser(description=__doc__)
    root=Path(__file__).resolve().parents[1]/"evaluation_dataset"
    p.add_argument("--eval-root",type=Path,default=root)
    p.add_argument("--checkpoint",action="append",required=True,help="name=base-or-adapter-path; include sft=...")
    p.add_argument("--output-dir",type=Path,required=True)
    p.add_argument("--predictions",type=Path)
    p.add_argument("--max-new-tokens",type=int,default=48)
    p.add_argument("--score-only",action="store_true")
    p.add_argument("--bootstrap",type=int,default=2000)
    a=p.parse_args()
    manifest, prompts=load_eval(a.eval_root)
    if not a.score_only:
        checkpoint_names=[item.split("=",1)[0] for item in a.checkpoint]
        required={"pretrained","sft","retain_only","GA","GD","NPO"}
        if len(checkpoint_names)!=len(set(checkpoint_names)) or set(checkpoint_names)!=required:
            raise RuntimeError(f"R1 diagnostics require exactly one each of {sorted(required)}")
    a.output_dir.mkdir(parents=True,exist_ok=True)
    pred=a.predictions or a.output_dir/"predictions.jsonl"
    if not a.score_only: generate(manifest,prompts,a.checkpoint,pred,a.max_new_tokens)
    labels=load_labels(a.eval_root)
    score(pred,labels,a.output_dir,a.bootstrap)
    print(json.dumps({"status":"EVALUATION_COMPLETE","checkpoints":a.checkpoint,"predictions":str(pred),"report":str(a.output_dir/"diagnostic_report.md"),"translation_review_mode":"AI_ONLY","human_translation_reviewed":False},indent=2))


if __name__=="__main__": main()
