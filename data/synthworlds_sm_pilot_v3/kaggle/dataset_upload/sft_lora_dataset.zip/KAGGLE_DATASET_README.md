# SynthWorlds-SM Kaggle SFT feasibility pilot

This package contains the approved-for-pilot five-language SFT corpus and the Kaggle runner. It is approved for an AI-only feasibility pilot under the user's explicit instruction. It is **not human-validated multilingual data**: no fluent human reviewed these translations, and the draft translator and back-translation audit use the same NLLB-200 distilled 600M model family. Back-translation is a consistency check, not proof of fluency or semantic accuracy.

The pilot split approval is a delegated AI technical review for this limited 129-case feasibility split; it is not researcher sign-off or a powered main-study design. The audit files and checksums are included for traceability.

In Kaggle, attach this dataset to `sft_lora_pilot.ipynb`. Run through preflight first. Training remains disabled by default (`RUN_TRAINING = False`); only enable it after GPU, secret, gated-model access, and `READY_TO_TRAIN` checks pass and you decide to run this pilot.
